console.log("function");

// convert celcius to farenheit project //

        function converttemperature()
        
        {
       
        let Fahrenheit = (deg F);
        let Celcius = (deg C);
        const = (9/5 + 32);
        let (deg Celcius * const = deg farenheit);
        let (deg Celcius = a);
        let (deg farenheit = b);
        let (a* const = b)
        
        }


